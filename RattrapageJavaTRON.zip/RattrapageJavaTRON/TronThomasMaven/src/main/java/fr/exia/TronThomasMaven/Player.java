package fr.exia.TronThomasMaven;
import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

public class Player extends GameObject {
	Color color;
	boolean alive = true;
	int startVel = 0;
	static int WIDTH = 3;
	static int HEIGHT = 3;

	ArrayList<Shape> lines = new ArrayList<Shape>();
	public Player(int randX, int randY, int velx, int vely, Color color) {
		super(randX, randY, velx, vely, WIDTH, HEIGHT);
		startVel = Math.max(Math.abs(velx), Math.abs(vely));
		this.color = color;
	}
	public void draw(Graphics g) {
		g.setColor(color);
		g.fillRect(x - WIDTH/2, y - HEIGHT/2, WIDTH, HEIGHT);
		for (Shape k: lines) {
			k.draw(g);
		}
	}	
	public boolean getAlive() {
		return alive;
	}	
	public ArrayList<Shape> getPath() {
		return lines;
	}
	public void crash(Intersection i) {
		if (i == Intersection.UP) {
			velocityX = 0;
			velocityY = 0;
			alive = false;
		}
	}
	public void move() {
		int a = x;
		int b = y;
			x += velocityX;
			y += velocityY;
			if (lines.size() > 1) {
				Shape l1 = lines.get(lines.size() - 2);
				Shape l2 = lines.get(lines.size() - 1);
				if (a == l1.getStartX() && 
						l1.getEndY() == l2.getStartY()) {
					lines.add(new Line(l1.getStartX(), l1.getStartY(),
							l2.getEndX(), l2.getEndY()));
					lines.remove(lines.size() - 2);
					lines.remove(lines.size() - 2);
				} else if (b == l1.getStartY() && 
						l1.getEndX() == l2.getStartX()) {
					lines.add(new Line(l1.getStartX(), l1.getStartY(), 
							l2.getEndX(), l2.getEndY()));
					lines.remove(lines.size() - 2);
					lines.remove(lines.size() - 2);
				} 
			}
			lines.add(new Line(a, b, x, y));
		clip();
	}
	
	void addPlayers(Player[] players){};
	
}