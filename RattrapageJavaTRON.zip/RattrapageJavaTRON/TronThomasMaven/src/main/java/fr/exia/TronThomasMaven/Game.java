package fr.exia.TronThomasMaven;
import java.awt.*;
import javax.swing.*;

public class Game implements Runnable {
	
	public void run() {
	   
      final JFrame frame = new JFrame("Tron Game");
      frame.setBackground(Color.BLACK);
      frame.setPreferredSize(new Dimension(600,400));
      frame.setLocation(400, 100);
      frame.setResizable(false);
      final TronMap levelTwoPlayer = 
    		  new TronMap(2);
      levelTwoPlayer.setBorder(BorderFactory.createLineBorder(Color.BLACK));
      frame.add(levelTwoPlayer);
      frame.update(frame.getGraphics());
      levelTwoPlayer.requestFocusInWindow();
      levelTwoPlayer.revalidate();
      levelTwoPlayer.reset();
      frame.pack();
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setVisible(true);
      levelTwoPlayer.reset();
   }
   
   public static void main(String[] args) {
       SwingUtilities.invokeLater(new Game());
   }
   
  
	   
   
   
   
   
}
