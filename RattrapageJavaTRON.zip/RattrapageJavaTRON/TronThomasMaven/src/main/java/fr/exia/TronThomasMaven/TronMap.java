package fr.exia.TronThomasMaven;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Random;
import javax.swing.*;

import com.mysql.jdbc.Statement;

public class TronMap extends JComponent {
	
	// the player and all other players
	Player player;
	Player player2;
	Player[] players;
	
	Random rand = new Random();
	
	int MAPWIDTH = 600;
	int MAPHEIGHT = 400;	
	int VELOCITY = 3;
	boolean victoire1 = false;
	boolean victoire2 = false;
	boolean egalite = false;
	int interval = 20;
	Timer timer;
	boolean run = true;
	
	public TronMap(int p) {
		setBackground(Color.WHITE);
		if (p > 8) { p = 8; }
		this.players = new Player[p];

		
		setBorder(BorderFactory.createLineBorder(Color.BLACK));
		setFocusable(true);
		
		timer = new Timer(interval, new ActionListener() {
			public void actionPerformed(ActionEvent e) { 
				tick();
			}
		});
		timer.start();
		
		addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e) {
				if (!player.getAlive()) {
				} else if (e.getKeyCode() == KeyEvent.VK_LEFT) {
					if (player.velocityX == -3 && player.velocityY == 0){		
						player.setXVelocity(0);
						player.setYVelocity(VELOCITY);}
					else if (player.velocityX == 3 && player.velocityY == 0){		
						player.setXVelocity(0);
						player.setYVelocity(-VELOCITY);}
					else if (player.velocityX == 0 && player.velocityY == -3){	
						player.setXVelocity(-VELOCITY);
						player.setYVelocity(0);}
					else if (player.velocityX == 0 && player.velocityY == 3){	
						player.setXVelocity(VELOCITY);
						player.setYVelocity(0);}
				} else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
					if (player.velocityX == -3 && player.velocityY == 0){		
						player.setXVelocity(0);
						player.setYVelocity(-VELOCITY);}
					else if (player.velocityX == 3 && player.velocityY == 0){		
						player.setXVelocity(0);
						player.setYVelocity(VELOCITY);}
					else if (player.velocityX == 0 && player.velocityY == -3){	
						player.setXVelocity(VELOCITY);
						player.setYVelocity(0);}
					else if (player.velocityX == 0 && player.velocityY == 3){	
						player.setXVelocity(-VELOCITY);
						player.setYVelocity(0);}
				} 
			}
			public void keyReleased(KeyEvent e) {
			}
		});
		
		addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e) {
				if (!player2.getAlive()) {
				} else if (e.getKeyCode() == KeyEvent.VK_W) {
					if (player2.velocityX == -3 && player2.velocityY == 0){		
						player2.setXVelocity(0);
						player2.setYVelocity(VELOCITY);}
					else if (player2.velocityX == 3 && player2.velocityY == 0){		
						player2.setXVelocity(0);
						player2.setYVelocity(-VELOCITY);}
					else if (player2.velocityX == 0 && player2.velocityY == -3){	
						player2.setXVelocity(-VELOCITY);
						player2.setYVelocity(0);}
					else if (player2.velocityX == 0 && player2.velocityY == 3){	
						player2.setXVelocity(VELOCITY);
						player2.setYVelocity(0);}
				} else if (e.getKeyCode() == KeyEvent.VK_C) {
					if (player2.velocityX == -3 && player2.velocityY == 0){		
						player2.setXVelocity(0);
						player2.setYVelocity(-VELOCITY);}
					else if (player2.velocityX == 3 && player2.velocityY == 0){		
						player2.setXVelocity(0);
						player2.setYVelocity(VELOCITY);}
					else if (player2.velocityX == 0 && player2.velocityY == -3){	
						player2.setXVelocity(VELOCITY);
						player2.setYVelocity(0);}
					else if (player2.velocityX == 0 && player2.velocityY == 3){	
						player2.setXVelocity(-VELOCITY);
						player2.setYVelocity(0);}
				} 
			}
			public void keyReleased(KeyEvent e) {
			}
		});		
	}

		void tick() {
			player.setBounds(getWidth(), getHeight());
			player.move();
			player2.setBounds(getWidth(), getHeight());
			player2.move();
			for (Player k1: players) {
				for (Player k2: players) {
					k1.crash(k1.intersects(k2));
				}
			}
			if (!player.getAlive() || !player2.getAlive()) {
				timer.stop();
				run = false;
				addScore();
			} 
			repaint();
		}
		
		public void restartGame() {}
		
		public void reset() {
			victoire1 = false;
			victoire2 = false;
			egalite = false;
			int[] start1 = getRandomStart();
			player = new Player
					(start1[0], start1[1], start1[2], start1[3], Color.WHITE);
			players[0] = player;
			int[] start2 = getRandomStart();
			player2 = new Player
					(start2[0], start2[1], start2[2], start2[3], Color.RED);
			players[1] = player2;
			timer.start();
			requestFocusInWindow();
		}
		
		public void addScore() {
			if (!run) {
				if (player2.getAlive()) {
					victoire2 = true;
				} else if (player.getAlive()) {
					victoire1 = true;
				} else {
					egalite = true;
				}
			}
		}
		
		@Override
		public void paintComponent(Graphics g) {
		   super.paintComponent(g);
		   super.paintComponent(g);
		   g.setColor(Color.BLACK);
		   g.fillRect(0, 0, MAPWIDTH, MAPHEIGHT);
		   for (Player p: players) {
			   if (p != null) {
				   p.draw(g);
			   }
		   }
		   if (victoire1) {	
			   sauverEnBase("Le joueur 1 a gagner");

				  JOptionPane.showMessageDialog(null, "Le joueur 1 a gagne");
				  System.exit(1);
				  
		   }
		   if (victoire2) {	
			   sauverEnBase("Le joueur 2 a gagner");

			   JOptionPane.showMessageDialog(null, "Le joueur 2 a gagne");
			   System.exit(1);
		   }
		   if (egalite) { 
			   sauverEnBase("Egalite");
			   JOptionPane.showMessageDialog(null, "Egalite");
			   System.exit(1);
			  
		   }		
	}
	
	public int[] getRandomStart() {
		int[] start = new int[4];
		int xnew = 50 + rand.nextInt(400);
		int ynew = 50 + rand.nextInt(400);
		int ra = rand.nextInt(2);
		int velx = 0;
		int vely = 0;
		if (ra == 0) {
			if (xnew < 250) {
				velx = VELOCITY;
			} else {
				velx = -VELOCITY;
			}
		} else {
			if (ynew < 250) {
				vely = VELOCITY;
			} else {
				vely = -VELOCITY;
			}
		}
		start[0] = xnew;
		start[1] = ynew;
		start[2] = velx;
		start[3] = vely;
		return start;
	}
	public static void sauverEnBase (String personne)
	{
	String url = "jdbc:mysql://localhost:8889/formation";
	String login = "root";
	String passwd = "root";
	Connection cn =null;
	Statement st =null;
	try
	{
		Class.forName("com.mysql.jdbc.Driver");
		cn = DriverManager.getConnection(url, login, passwd);
		st = (Statement) cn.createStatement();
		String sql = "INSERT INTO javadb (personne) VALUES ('"+personne+"')";
		st.executeUpdate(sql);}
		catch (SQLException e){
			e.printStackTrace();
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}finally {
			try{
				cn.close();
				st.close();
			}catch (SQLException e){
				e.printStackTrace();
			}
		}
		
	}
}