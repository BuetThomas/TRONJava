package fr.exia.TronThomasMaven;
import java.awt.Graphics;
import java.util.ArrayList;

public abstract class GameObject {
	int x; 
	int y;
	int width; 
	int height;
	int velocityX;
	int velocityY;
	int rightBound;
	int bottomBound;

	public GameObject(int x, int y, int velocityX, int velocityY, int width,
			int height) {
		this.x = x;
		this.y = y;
		this.velocityX = velocityX;
		this.velocityY = velocityY;
		this.width = width;
		this.height = height;
	}

	public void setBounds(int width, int height) {
		rightBound = width - this.width;
		bottomBound = height - this.height;
	}

	public void setXVelocity(int velocityX) {
		if (!(velocityX > 0 && this.velocityX < 0)
				&& !(velocityX < 0 && this.velocityX > 0)) {
			this.velocityX = velocityX;
		}
	}

	public void setYVelocity(int velocityY) {
		if (!(velocityY > 0 && this.velocityY < 0)
				&& !(velocityY < 0 && this.velocityY > 0)) {
			this.velocityY = velocityY;
		}
	}

	public void move() {
		x += velocityX;
		y += velocityY;
		clip();
	}

	public void clip() {
		if (x < 0)
			x = 0;
		else if (x > rightBound)
			x = rightBound;

		if (y < 0)
			y = 0;
		else if (y > bottomBound)
			y = bottomBound;
	}

	public Intersection intersects(GameObject other) {
		if (other != this) {
			if (other.y - other.height/2 <= y + height/2 &&
				other.y + other.height/2 >= y - height/2 &&
				other.x - other.width/2 <= x + width/2 &&
				other.x + other.width/2 >= x - width/2) {
				return Intersection.UP;
			}
		}
		ArrayList<Shape> pa = other.getPath();
		for (int i = 0; i < pa.size() - 1; i++) {
			Shape k = pa.get(i);
			int x1 = k.getStartX();
			int y1 = k.getStartY();
			int x2 = k.getEndX();
			int y2 = k.getEndY();

			if (y1 == y2) {
				if (Math.abs(y1 - y) <= height/2 && 
					(x >= Math.min(x1, x2) && x <= Math.max(x1, x2))) {
					return Intersection.UP;
				}
			} else if (x1 == x2) {
				if (Math.abs(x1 - x) <= width/2 &&
					(y >= Math.min(y1, y2) && y <= Math.max(y1, y2))) {					
					return Intersection.UP;
				}
			}
		}
		return Intersection.NONE;
	}
	
	public abstract void draw(Graphics g);
	public abstract boolean getAlive();
	public abstract ArrayList<Shape> getPath();
}
