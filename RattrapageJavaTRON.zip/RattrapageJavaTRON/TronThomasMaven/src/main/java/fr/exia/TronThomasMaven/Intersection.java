package fr.exia.TronThomasMaven;
public enum Intersection {
    NONE, UP, LEFT, DOWN, RIGHT
}